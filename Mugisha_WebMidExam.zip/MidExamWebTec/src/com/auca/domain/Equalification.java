package com.auca.domain;


public enum Equalification {
    BACHELOR, MASTER, PHD;
}
